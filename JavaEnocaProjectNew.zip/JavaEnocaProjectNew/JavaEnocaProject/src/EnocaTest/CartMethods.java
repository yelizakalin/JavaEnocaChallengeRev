package EnocaTest;
public interface CartMethods
{

    void getCart();
    void emptyCart();
    void updateCart(Product product, int newQuantity);
}
